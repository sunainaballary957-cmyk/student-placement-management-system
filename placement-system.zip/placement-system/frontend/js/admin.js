requireAuth("admin");

document.querySelectorAll(".nav-item").forEach(item => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(i => i.classList.remove("active"));
    item.classList.add("active");
    document.querySelectorAll("main > section").forEach(s => s.classList.add("hidden"));
    document.getElementById(`section-${item.dataset.section}`).classList.remove("hidden");
  });
});

const CHART_COLORS = {
  brand: "#6d7cff",
  green: "#3ddc97",
  amber: "#f5b942",
  red: "#f2607a",
  grid: "rgba(255,255,255,0.06)",
  text: "#9aa7b8",
};
Chart.defaults.color = CHART_COLORS.text;
Chart.defaults.font.family = "Inter, sans-serif";

async function loadAnalytics() {
  const data = await api("/admin/analytics");
  document.getElementById("statTotalStudents").textContent = data.total_students;
  document.getElementById("statTotalCompanies").textContent = data.total_companies;
  document.getElementById("statTotalPlaced").textContent = data.total_placed;
  document.getElementById("statPlacementPct").textContent = data.placement_percentage + "%";

  new Chart(document.getElementById("branchChart"), {
    type: "bar",
    data: {
      labels: data.branch_stats.map(b => b.branch),
      datasets: [
        { label: "Placed", data: data.branch_stats.map(b => b.placed), backgroundColor: CHART_COLORS.green, borderRadius: 6 },
        { label: "Total students", data: data.branch_stats.map(b => b.total), backgroundColor: "rgba(255,255,255,0.12)", borderRadius: 6 },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { labels: { boxWidth: 10 } } },
      scales: {
        x: { grid: { display: false } },
        y: { grid: { color: CHART_COLORS.grid }, beginAtZero: true, ticks: { precision: 0 } },
      },
    },
  });

  const placed = data.total_placed;
  const unplaced = Math.max(data.total_students - placed, 0);
  new Chart(document.getElementById("pieChart"), {
    type: "doughnut",
    data: {
      labels: ["Placed", "Not yet placed"],
      datasets: [{ data: [placed, unplaced], backgroundColor: [CHART_COLORS.green, "rgba(255,255,255,0.12)"], borderWidth: 0 }],
    },
    options: { responsive: true, plugins: { legend: { position: "bottom", labels: { boxWidth: 10 } } } },
  });

  new Chart(document.getElementById("packageChart"), {
    type: "line",
    data: {
      labels: data.package_distribution.map((_, i) => `Company ${i + 1}`),
      datasets: [{ label: "CTC (LPA)", data: data.package_distribution, borderColor: CHART_COLORS.brand, backgroundColor: "rgba(109,124,255,0.15)", fill: true, tension: 0.35, pointBackgroundColor: CHART_COLORS.brand }],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { x: { grid: { display: false } }, y: { grid: { color: CHART_COLORS.grid }, beginAtZero: true } },
    },
  });
}

// ---------- Companies management ----------
async function loadCompaniesAdmin() {
  const companies = await api("/companies");
  const list = document.getElementById("companiesAdminList");
  list.innerHTML = "";
  if (!companies.length) {
    list.innerHTML = `<div class="empty-state">No companies added yet.</div>`;
    return;
  }
  companies.forEach(c => {
    const row = document.createElement("div");
    row.className = "card card-tight";
    row.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:flex-start;">
        <div>
          <div class="company-name">${c.name}</div>
          <div class="company-role">${c.role} · ₹${c.package_ctc} LPA · min CGPA ${c.min_cgpa}</div>
          <div class="skill-tag-row" style="margin-top:8px;">
            ${c.required_skills.map(s => `<span class="skill-tag">${s.name}</span>`).join("")}
          </div>
        </div>
        <button class="btn btn-danger btn-sm" data-id="${c.id}">Remove</button>
      </div>
    `;
    row.querySelector("button").addEventListener("click", async () => {
      try {
        await api(`/admin/companies/${c.id}`, { method: "DELETE" });
        toast(`Removed ${c.name}`);
        loadCompaniesAdmin();
        loadAnalytics();
      } catch (err) { toast(err.message, "error"); }
    });
    list.appendChild(row);
  });
}

document.getElementById("companyForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const skills = document.getElementById("cSkills").value.split(",").map(s => s.trim()).filter(Boolean);
  try {
    await api("/admin/companies", {
      method: "POST",
      body: {
        name: document.getElementById("cName").value,
        role: document.getElementById("cRole").value,
        package_ctc: parseFloat(document.getElementById("cPackage").value) || 0,
        min_cgpa: parseFloat(document.getElementById("cMinCgpa").value) || 0,
        eligible_branches: document.getElementById("cBranches").value,
        description: document.getElementById("cDescription").value,
        required_skill_names: skills,
      },
    });
    toast("Company added");
    document.getElementById("companyForm").reset();
    loadCompaniesAdmin();
    loadAnalytics();
  } catch (err) { toast(err.message, "error"); }
});

// ---------- Students table ----------
async function loadStudents() {
  const students = await api("/admin/students");
  const tbody = document.getElementById("studentsTableBody");
  tbody.innerHTML = students.map(s => `
    <tr>
      <td>${s.name}</td>
      <td>${s.branch}</td>
      <td>${s.batch_year}</td>
      <td class="mono">${s.overall_cgpa.toFixed(2)}</td>
      <td>${s.skills.map(sk => sk.skill.name).join(", ") || "—"}</td>
    </tr>`).join("");
}

(async function init() {
  try {
    await loadAnalytics();
    await loadCompaniesAdmin();
    await loadStudents();
  } catch (err) { toast(err.message, "error"); }
})();
